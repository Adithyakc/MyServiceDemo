package com.example.myservicedemo;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import com.example.cameraserviceinterface.ICameraListener;
import static com.example.cameraserviceinterface.constants.CameraHmiServiceConstants.TAG;

import java.util.HashMap;

public class CameraAppServiceManager {
    CameraService mCameraService;

    private final RemoteCallbackList<ICameraListener>
            mCameraNotificationCallbackList = new RemoteCallbackList<>();

    private Handler mHandler = new Handler();
    /**
     * Member variable to store camera status;
     */
    private boolean mCameraStatus;

    SharedPreferences sh;
    private static final CameraAppServiceManager CAMERA_APP_SERVICE_MANAGER = new
            CameraAppServiceManager();

    /**
     * @brief Method to get singleton object of this class
     * @return CameraAppServiceManager: singleton object of this class
     */
    public static CameraAppServiceManager getCameraAppServiceManager() {
        return CAMERA_APP_SERVICE_MANAGER;
    }


    private ICameraListener mCameraListener = new ICameraListener.Stub(){
        @Override
        public void notifyCameraStatus(boolean status) throws RemoteException {

            mHandler.post(new Runnable() {
                @Override
                public void run() {

                    Log.d(TAG, "Inside notifyCameraStatus:" + mCameraStatus);
                    int broadcastCount = mCameraNotificationCallbackList.beginBroadcast();
                    /**
                     * This for loop iterates through number of application bind to service
                     */
                    try {
                        for (int i = 0; i < broadcastCount; i++) {
                            mCameraNotificationCallbackList.getBroadcastItem(i)
                                    .notifyCameraStatus(mCameraStatus);
                        }
                    } catch (RemoteException e) {
                        Log.e(TAG, "notifyCameraStatus " + e);
                    } finally {
                        mCameraNotificationCallbackList.finishBroadcast();
                    }
                }
            });
        }

    };

    public String getPreviousActiveCamera() {
        return "Rear View Camera";
    }

    public void registerAsyncConnection(ICameraListener mCameraListener) throws RemoteException {
        mCameraNotificationCallbackList.register(mCameraListener);
    }

    public void unregisterAsyncConnection(ICameraListener mCameraListener) throws RemoteException {
        mCameraNotificationCallbackList.unregister(mCameraListener);
    }

    public void startCamera() throws RemoteException{

        mCameraStatus = !mCameraStatus;
        mCameraListener.notifyCameraStatus(mCameraStatus);
    }

    private HashMap<String, Object> hashMap;
    public void notifySetting(boolean status){
//         sh = mCameraService.getSharedPreferences("CAMERA SETTING", Context.MODE_PRIVATE);
//         SharedPreferences.Editor editor = sh.edit();
//         editor.putBoolean("status",status);
//         editor.apply();
//         Boolean checkStatus = sh.getBoolean("status",status);
//         getSettings(checkStatus);
         HashMap<Integer,Boolean> hash_map = new HashMap<Integer,Boolean>();

         hash_map.put(1,status);
         getSettings(1);
     }

    public Boolean getSettings(int status){
        Log.d("setting status","status");
        return (Boolean) hashMap.get(status);
    }

}
